var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { Injectable } from '@angular/core';
import { IonicNativePlugin, cordova } from '@ionic-native/core';
var geospark = /** @class */ (function (_super) {
    __extends(geospark, _super);
    function geospark() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    geospark.prototype.disableBatteryOptimization = function () { return cordova(this, "disableBatteryOptimization", {}, arguments); };
    geospark.prototype.isBatteryOptimizationEnabled = function () { return cordova(this, "isBatteryOptimizationEnabled", {}, arguments); };
    geospark.prototype.checkActivityPermission = function () { return cordova(this, "checkActivityPermission", {}, arguments); };
    geospark.prototype.requestActivityPermission = function () { return cordova(this, "requestActivityPermission", {}, arguments); };
    geospark.prototype.checkLocationPermission = function () { return cordova(this, "checkLocationPermission", {}, arguments); };
    geospark.prototype.requestLocationPermission = function () { return cordova(this, "requestLocationPermission", {}, arguments); };
    geospark.prototype.checkLocationServices = function () { return cordova(this, "checkLocationServices", {}, arguments); };
    geospark.prototype.requestLocationServices = function () { return cordova(this, "requestLocationServices", {}, arguments); };
    geospark.prototype.checkBackgroundLocationPermission = function () { return cordova(this, "checkBackgroundLocationPermission", {}, arguments); };
    geospark.prototype.requestBackgroundLocationPermission = function () { return cordova(this, "requestBackgroundLocationPermission", {}, arguments); };
    geospark.prototype.getDeviceToken = function () { return cordova(this, "getDeviceToken", {}, arguments); };
    geospark.prototype.createUser = function (description) { return cordova(this, "createUser", {}, arguments); };
    geospark.prototype.setDescription = function (description) { return cordova(this, "setDescription", {}, arguments); };
    geospark.prototype.getUser = function (description) { return cordova(this, "getUser", {}, arguments); };
    geospark.prototype.toggleEvents = function (geofenceEvents, tripEvents, activityEvents) { return cordova(this, "toggleEvents", {}, arguments); };
    geospark.prototype.getEventsStatus = function () { return cordova(this, "getEventsStatus", {}, arguments); };
    geospark.prototype.startTrip = function (description, tripId) { return cordova(this, "startTrip", {}, arguments); };
    geospark.prototype.resumeTrip = function (tripId) { return cordova(this, "resumeTrip", {}, arguments); };
    geospark.prototype.pauseTrip = function (tripId) { return cordova(this, "pauseTrip", {}, arguments); };
    geospark.prototype.endTrip = function (tripId) { return cordova(this, "endTrip", {}, arguments); };
    geospark.prototype.activeTrips = function () { return cordova(this, "activeTrips", {}, arguments); };
    geospark.prototype.getCurrentLocation = function (accuracy) { return cordova(this, "getCurrentLocation", {}, arguments); };
    geospark.prototype.updateCurrentLocation = function (accuracy) { return cordova(this, "updateCurrentLocation", {}, arguments); };
    geospark.prototype.startTracking = function () { return cordova(this, "startTracking", {}, arguments); };
    geospark.prototype.stopTracking = function () { return cordova(this, "stopTracking", {}, arguments); };
    geospark.prototype.isLocationTracking = function () { return cordova(this, "isLocationTracking", {}, arguments); };
    geospark.prototype.logout = function () { return cordova(this, "logout", {}, arguments); };
    geospark.prototype.setTrackingInAppState = function (typeArray) { return cordova(this, "setTrackingInAppState", {}, arguments); };
    geospark.prototype.setTrackingInMotion = function (typeArray) { return cordova(this, "setTrackingInMotion", {}, arguments); };
    geospark.prototype.onEvents = function () { return cordova(this, "onEvents", {}, arguments); };
    geospark.prototype.onError = function () { return cordova(this, "onError", {}, arguments); };
    geospark.prototype.offEvents = function () { return cordova(this, "offEvents", {}, arguments); };
    geospark.prototype.offError = function () { return cordova(this, "offError", {}, arguments); };
    geospark.pluginName = "Geospark";
    geospark.plugin = "cordova-plugin-geospark";
    geospark.pluginRef = "cordova.plugins.geospark";
    geospark.repo = "https://github.com/geosparks/cordova-plugin-geospark";
    geospark.platforms = ["Android", "iOS"];
    geospark = __decorate([
        Injectable()
    ], geospark);
    return geospark;
}(IonicNativePlugin));
export { geospark };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvQGlvbmljLW5hdGl2ZS9wbHVnaW5zL2dlb3NwYXJrL25neC9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFPLDhCQUEwRixNQUFNLG9CQUFvQixDQUFDOztJQVc5Riw0QkFBaUI7Ozs7SUFHN0MsNkNBQTBCO0lBSTFCLCtDQUE0QjtJQUk1QiwwQ0FBdUI7SUFJdkIsNENBQXlCO0lBSXpCLDBDQUF1QjtJQUl2Qiw0Q0FBeUI7SUFJekIsd0NBQXFCO0lBSXJCLDBDQUF1QjtJQUl2QixvREFBaUM7SUFJakMsc0RBQW1DO0lBSW5DLGlDQUFjO0lBSWQsNkJBQVUsYUFBQyxXQUFtQjtJQUk5QixpQ0FBYyxhQUFDLFdBQW1CO0lBSWxDLDBCQUFPLGFBQUMsV0FBbUI7SUFJM0IsK0JBQVksYUFBQyxjQUF1QixFQUFFLFVBQW1CLEVBQUcsY0FBdUI7SUFJbkYsa0NBQWU7SUFJZiw0QkFBUyxhQUFDLFdBQW1CLEVBQUUsTUFBYztJQUk3Qyw2QkFBVSxhQUFDLE1BQWM7SUFJekIsNEJBQVMsYUFBQyxNQUFjO0lBSXhCLDBCQUFPLGFBQUMsTUFBYztJQUl0Qiw4QkFBVztJQUlYLHFDQUFrQixhQUFDLFFBQWdCO0lBSW5DLHdDQUFxQixhQUFDLFFBQWdCO0lBSXRDLGdDQUFhO0lBSWIsK0JBQVk7SUFJWixxQ0FBa0I7SUFJbEIseUJBQU07SUFJTix3Q0FBcUIsYUFBQyxTQUFpQjtJQUl2QyxzQ0FBbUIsYUFBQyxTQUFpQjtJQUlyQywyQkFBUTtJQUlSLDBCQUFPO0lBSVAsNEJBQVM7SUFJVCwyQkFBUTs7Ozs7O0lBbklHLFFBQVE7UUFEcEIsVUFBVSxFQUFFO09BQ0EsUUFBUTttQkFackI7RUFZOEIsaUJBQWlCO1NBQWxDLFFBQVEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBQbHVnaW4sIENvcmRvdmEsIENvcmRvdmFQcm9wZXJ0eSwgQ29yZG92YUluc3RhbmNlLCBJbnN0YW5jZVByb3BlcnR5LCBJb25pY05hdGl2ZVBsdWdpbiB9IGZyb20gJ0Bpb25pYy1uYXRpdmUvY29yZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5cbkBQbHVnaW4oe1xuICBwbHVnaW5OYW1lOiAnR2Vvc3BhcmsnLFxuICBwbHVnaW46IFwiY29yZG92YS1wbHVnaW4tZ2Vvc3BhcmtcIixcbiAgcGx1Z2luUmVmOiBcImNvcmRvdmEucGx1Z2lucy5nZW9zcGFya1wiLFxuICByZXBvOiBcImh0dHBzOi8vZ2l0aHViLmNvbS9nZW9zcGFya3MvY29yZG92YS1wbHVnaW4tZ2Vvc3BhcmtcIixcbiAgcGxhdGZvcm1zOiBbXCJBbmRyb2lkXCIsIFwiaU9TXCJdXG59KVxuQEluamVjdGFibGUoKVxuZXhwb3J0IGNsYXNzIGdlb3NwYXJrIGV4dGVuZHMgSW9uaWNOYXRpdmVQbHVnaW4ge1xuIFxuICBAQ29yZG92YSgpXG4gIGRpc2FibGVCYXR0ZXJ5T3B0aW1pemF0aW9uKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgaXNCYXR0ZXJ5T3B0aW1pemF0aW9uRW5hYmxlZCgpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIGNoZWNrQWN0aXZpdHlQZXJtaXNzaW9uKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgcmVxdWVzdEFjdGl2aXR5UGVybWlzc2lvbigpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIGNoZWNrTG9jYXRpb25QZXJtaXNzaW9uKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgcmVxdWVzdExvY2F0aW9uUGVybWlzc2lvbigpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIGNoZWNrTG9jYXRpb25TZXJ2aWNlcygpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIHJlcXVlc3RMb2NhdGlvblNlcnZpY2VzKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgY2hlY2tCYWNrZ3JvdW5kTG9jYXRpb25QZXJtaXNzaW9uKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgcmVxdWVzdEJhY2tncm91bmRMb2NhdGlvblBlcm1pc3Npb24oKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBnZXREZXZpY2VUb2tlbigpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIGNyZWF0ZVVzZXIoZGVzY3JpcHRpb246IFN0cmluZyk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgc2V0RGVzY3JpcHRpb24oZGVzY3JpcHRpb246IFN0cmluZyk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgZ2V0VXNlcihkZXNjcmlwdGlvbjogU3RyaW5nKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICB0b2dnbGVFdmVudHMoZ2VvZmVuY2VFdmVudHM6IEJvb2xlYW4gLHRyaXBFdmVudHM6IEJvb2xlYW4gLCBhY3Rpdml0eUV2ZW50czogQm9vbGVhbik6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgZ2V0RXZlbnRzU3RhdHVzKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgc3RhcnRUcmlwKGRlc2NyaXB0aW9uOiBTdHJpbmcsIHRyaXBJZDogU3RyaW5nKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICByZXN1bWVUcmlwKHRyaXBJZDogU3RyaW5nKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBwYXVzZVRyaXAodHJpcElkOiBTdHJpbmcpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIGVuZFRyaXAodHJpcElkOiBTdHJpbmcpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIGFjdGl2ZVRyaXBzKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgZ2V0Q3VycmVudExvY2F0aW9uKGFjY3VyYWN5OiBOdW1iZXIpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIHVwZGF0ZUN1cnJlbnRMb2NhdGlvbihhY2N1cmFjeTogTnVtYmVyKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBzdGFydFRyYWNraW5nKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgc3RvcFRyYWNraW5nKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgaXNMb2NhdGlvblRyYWNraW5nKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgbG9nb3V0KCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgc2V0VHJhY2tpbmdJbkFwcFN0YXRlKHR5cGVBcnJheTogU3RyaW5nKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBzZXRUcmFja2luZ0luTW90aW9uKHR5cGVBcnJheTogU3RyaW5nKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBvbkV2ZW50cygpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIG9uRXJyb3IoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBvZmZFdmVudHMoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBvZmZFcnJvcigpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxufVxuIl19