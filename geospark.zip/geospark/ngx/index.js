var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { Injectable } from '@angular/core';
import { IonicNativePlugin, cordova } from '@ionic-native/core';
import { Observable } from 'rxjs';
var geospark = /** @class */ (function (_super) {
    __extends(geospark, _super);
    function geospark() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    geospark.prototype.disableBatteryOptimization = function () { return cordova(this, "disableBatteryOptimization", {}, arguments); };
    geospark.prototype.isBatteryOptimizationEnabled = function () { return cordova(this, "isBatteryOptimizationEnabled", {}, arguments); };
    geospark.prototype.checkActivityPermission = function () { return cordova(this, "checkActivityPermission", {}, arguments); };
    geospark.prototype.requestActivityPermission = function () { return cordova(this, "requestActivityPermission", {}, arguments); };
    geospark.prototype.checkLocationPermission = function () { return cordova(this, "checkLocationPermission", {}, arguments); };
    geospark.prototype.requestLocationPermission = function () { return cordova(this, "requestLocationPermission", {}, arguments); };
    geospark.prototype.checkLocationServices = function () { return cordova(this, "checkLocationServices", {}, arguments); };
    geospark.prototype.requestLocationServices = function () { return cordova(this, "requestLocationServices", {}, arguments); };
    geospark.prototype.checkBackgroundLocationPermission = function () { return cordova(this, "checkBackgroundLocationPermission", {}, arguments); };
    geospark.prototype.requestBackgroundLocationPermission = function () { return cordova(this, "requestBackgroundLocationPermission", {}, arguments); };
    geospark.prototype.getDeviceToken = function () { return cordova(this, "getDeviceToken", {}, arguments); };
    geospark.prototype.createUser = function (description) { return cordova(this, "createUser", {}, arguments); };
    geospark.prototype.setDescription = function (description) { return cordova(this, "setDescription", {}, arguments); };
    geospark.prototype.getUser = function (description) { return cordova(this, "getUser", {}, arguments); };
    geospark.prototype.toggleEvents = function (geofenceEvents, tripEvents, activityEvents) { return cordova(this, "toggleEvents", {}, arguments); };
    geospark.prototype.getEventsStatus = function () { return cordova(this, "getEventsStatus", {}, arguments); };
    geospark.prototype.startTrip = function (description, tripId) { return cordova(this, "startTrip", {}, arguments); };
    geospark.prototype.resumeTrip = function (tripId) { return cordova(this, "resumeTrip", {}, arguments); };
    geospark.prototype.pauseTrip = function (tripId) { return cordova(this, "pauseTrip", {}, arguments); };
    geospark.prototype.endTrip = function (tripId) { return cordova(this, "endTrip", {}, arguments); };
    geospark.prototype.activeTrips = function () { return cordova(this, "activeTrips", {}, arguments); };
    geospark.prototype.getCurrentLocation = function (accuracy) { return cordova(this, "getCurrentLocation", {}, arguments); };
    geospark.prototype.updateCurrentLocation = function (accuracy) { return cordova(this, "updateCurrentLocation", {}, arguments); };
    geospark.prototype.startTracking = function () { return cordova(this, "startTracking", {}, arguments); };
    geospark.prototype.stopTracking = function () { return cordova(this, "stopTracking", {}, arguments); };
    geospark.prototype.isLocationTracking = function () { return cordova(this, "isLocationTracking", {}, arguments); };
    geospark.prototype.logout = function () { return cordova(this, "logout", {}, arguments); };
    geospark.prototype.setTrackingInAppState = function (typeArray) { return cordova(this, "setTrackingInAppState", {}, arguments); };
    geospark.prototype.setTrackingInMotion = function (typeArray) { return cordova(this, "setTrackingInMotion", {}, arguments); };
    geospark.prototype.onEvents = function () { return cordova(this, "onEvents", { "observable": true }, arguments); };
    geospark.prototype.onError = function () { return cordova(this, "onError", { "observable": true }, arguments); };
    geospark.prototype.offEvents = function () { return cordova(this, "offEvents", { "observable": true }, arguments); };
    geospark.prototype.offError = function () { return cordova(this, "offError", { "observable": true }, arguments); };
    geospark.pluginName = "Geospark";
    geospark.plugin = "cordova-plugin-geospark";
    geospark.pluginRef = "cordova.plugins.geospark";
    geospark.repo = "https://github.com/geosparks/cordova-plugin-geospark";
    geospark.platforms = ["Android", "iOS"];
    geospark = __decorate([
        Injectable()
    ], geospark);
    return geospark;
}(IonicNativePlugin));
export { geospark };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvQGlvbmljLW5hdGl2ZS9wbHVnaW5zL2dlb3NwYXJrL25neC9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFPLDhCQUEwRixNQUFNLG9CQUFvQixDQUFDO0FBQzVILE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxNQUFNLENBQUM7O0lBU0osNEJBQWlCOzs7O0lBRTdDLDZDQUEwQjtJQUkxQiwrQ0FBNEI7SUFJNUIsMENBQXVCO0lBSXZCLDRDQUF5QjtJQUl6QiwwQ0FBdUI7SUFJdkIsNENBQXlCO0lBSXpCLHdDQUFxQjtJQUlyQiwwQ0FBdUI7SUFJdkIsb0RBQWlDO0lBSWpDLHNEQUFtQztJQUluQyxpQ0FBYztJQUlkLDZCQUFVLGFBQUMsV0FBbUI7SUFJOUIsaUNBQWMsYUFBQyxXQUFtQjtJQUlsQywwQkFBTyxhQUFDLFdBQW1CO0lBSTNCLCtCQUFZLGFBQUMsY0FBdUIsRUFBRSxVQUFtQixFQUFHLGNBQXVCO0lBSW5GLGtDQUFlO0lBSWYsNEJBQVMsYUFBQyxXQUFtQixFQUFFLE1BQWM7SUFJN0MsNkJBQVUsYUFBQyxNQUFjO0lBSXpCLDRCQUFTLGFBQUMsTUFBYztJQUl4QiwwQkFBTyxhQUFDLE1BQWM7SUFJdEIsOEJBQVc7SUFJWCxxQ0FBa0IsYUFBQyxRQUFnQjtJQUluQyx3Q0FBcUIsYUFBQyxRQUFnQjtJQUl0QyxnQ0FBYTtJQUliLCtCQUFZO0lBSVoscUNBQWtCO0lBSWxCLHlCQUFNO0lBSU4sd0NBQXFCLGFBQUMsU0FBaUI7SUFJdkMsc0NBQW1CLGFBQUMsU0FBaUI7SUFNckMsMkJBQVE7SUFNUiwwQkFBTztJQU1QLDRCQUFTO0lBTVQsMkJBQVE7Ozs7OztJQTFJRyxRQUFRO1FBRHBCLFVBQVUsRUFBRTtPQUNBLFFBQVE7bUJBWHJCO0VBVzhCLGlCQUFpQjtTQUFsQyxRQUFRIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgUGx1Z2luLCBDb3Jkb3ZhLCBDb3Jkb3ZhUHJvcGVydHksIENvcmRvdmFJbnN0YW5jZSwgSW5zdGFuY2VQcm9wZXJ0eSwgSW9uaWNOYXRpdmVQbHVnaW4gfSBmcm9tICdAaW9uaWMtbmF0aXZlL2NvcmUnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xuQFBsdWdpbih7XG4gIHBsdWdpbk5hbWU6ICdHZW9zcGFyaycsXG4gIHBsdWdpbjogXCJjb3Jkb3ZhLXBsdWdpbi1nZW9zcGFya1wiLFxuICBwbHVnaW5SZWY6IFwiY29yZG92YS5wbHVnaW5zLmdlb3NwYXJrXCIsXG4gIHJlcG86IFwiaHR0cHM6Ly9naXRodWIuY29tL2dlb3NwYXJrcy9jb3Jkb3ZhLXBsdWdpbi1nZW9zcGFya1wiLFxuICBwbGF0Zm9ybXM6IFtcIkFuZHJvaWRcIiwgXCJpT1NcIl1cbn0pXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgZ2Vvc3BhcmsgZXh0ZW5kcyBJb25pY05hdGl2ZVBsdWdpbiB7XG4gIEBDb3Jkb3ZhKClcbiAgZGlzYWJsZUJhdHRlcnlPcHRpbWl6YXRpb24oKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBpc0JhdHRlcnlPcHRpbWl6YXRpb25FbmFibGVkKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgY2hlY2tBY3Rpdml0eVBlcm1pc3Npb24oKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICByZXF1ZXN0QWN0aXZpdHlQZXJtaXNzaW9uKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgY2hlY2tMb2NhdGlvblBlcm1pc3Npb24oKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICByZXF1ZXN0TG9jYXRpb25QZXJtaXNzaW9uKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgY2hlY2tMb2NhdGlvblNlcnZpY2VzKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgcmVxdWVzdExvY2F0aW9uU2VydmljZXMoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBjaGVja0JhY2tncm91bmRMb2NhdGlvblBlcm1pc3Npb24oKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICByZXF1ZXN0QmFja2dyb3VuZExvY2F0aW9uUGVybWlzc2lvbigpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIGdldERldmljZVRva2VuKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgY3JlYXRlVXNlcihkZXNjcmlwdGlvbjogU3RyaW5nKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBzZXREZXNjcmlwdGlvbihkZXNjcmlwdGlvbjogU3RyaW5nKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBnZXRVc2VyKGRlc2NyaXB0aW9uOiBTdHJpbmcpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIHRvZ2dsZUV2ZW50cyhnZW9mZW5jZUV2ZW50czogQm9vbGVhbiAsdHJpcEV2ZW50czogQm9vbGVhbiAsIGFjdGl2aXR5RXZlbnRzOiBCb29sZWFuKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBnZXRFdmVudHNTdGF0dXMoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBzdGFydFRyaXAoZGVzY3JpcHRpb246IFN0cmluZywgdHJpcElkOiBTdHJpbmcpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIHJlc3VtZVRyaXAodHJpcElkOiBTdHJpbmcpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIHBhdXNlVHJpcCh0cmlwSWQ6IFN0cmluZyk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgZW5kVHJpcCh0cmlwSWQ6IFN0cmluZyk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgYWN0aXZlVHJpcHMoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBnZXRDdXJyZW50TG9jYXRpb24oYWNjdXJhY3k6IE51bWJlcik6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgdXBkYXRlQ3VycmVudExvY2F0aW9uKGFjY3VyYWN5OiBOdW1iZXIpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIHN0YXJ0VHJhY2tpbmcoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBzdG9wVHJhY2tpbmcoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBpc0xvY2F0aW9uVHJhY2tpbmcoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBsb2dvdXQoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBzZXRUcmFja2luZ0luQXBwU3RhdGUodHlwZUFycmF5OiBTdHJpbmcpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIHNldFRyYWNraW5nSW5Nb3Rpb24odHlwZUFycmF5OiBTdHJpbmcpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSh7XG4gICAgb2JzZXJ2YWJsZTogdHJ1ZVxuICB9KVxuICBvbkV2ZW50cygpOiBPYnNlcnZhYmxlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSh7XG4gICAgb2JzZXJ2YWJsZTogdHJ1ZVxuICB9KVxuICBvbkVycm9yKCk6IE9ic2VydmFibGU8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKHtcbiAgICBvYnNlcnZhYmxlOiB0cnVlXG4gIH0pXG4gIG9mZkV2ZW50cygpOiBPYnNlcnZhYmxlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSh7XG4gICAgb2JzZXJ2YWJsZTogdHJ1ZVxuICB9KVxuICBvZmZFcnJvcigpOiBPYnNlcnZhYmxlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxufSJdfQ==