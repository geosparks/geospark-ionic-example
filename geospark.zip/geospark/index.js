var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
import { IonicNativePlugin, cordova } from '@ionic-native/core';
import { Observable } from 'rxjs';
var geosparkOriginal = /** @class */ (function (_super) {
    __extends(geosparkOriginal, _super);
    function geosparkOriginal() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    geosparkOriginal.prototype.disableBatteryOptimization = function () { return cordova(this, "disableBatteryOptimization", {}, arguments); };
    geosparkOriginal.prototype.isBatteryOptimizationEnabled = function () { return cordova(this, "isBatteryOptimizationEnabled", {}, arguments); };
    geosparkOriginal.prototype.checkActivityPermission = function () { return cordova(this, "checkActivityPermission", {}, arguments); };
    geosparkOriginal.prototype.requestActivityPermission = function () { return cordova(this, "requestActivityPermission", {}, arguments); };
    geosparkOriginal.prototype.checkLocationPermission = function () { return cordova(this, "checkLocationPermission", {}, arguments); };
    geosparkOriginal.prototype.requestLocationPermission = function () { return cordova(this, "requestLocationPermission", {}, arguments); };
    geosparkOriginal.prototype.checkLocationServices = function () { return cordova(this, "checkLocationServices", {}, arguments); };
    geosparkOriginal.prototype.requestLocationServices = function () { return cordova(this, "requestLocationServices", {}, arguments); };
    geosparkOriginal.prototype.checkBackgroundLocationPermission = function () { return cordova(this, "checkBackgroundLocationPermission", {}, arguments); };
    geosparkOriginal.prototype.requestBackgroundLocationPermission = function () { return cordova(this, "requestBackgroundLocationPermission", {}, arguments); };
    geosparkOriginal.prototype.getDeviceToken = function () { return cordova(this, "getDeviceToken", {}, arguments); };
    geosparkOriginal.prototype.createUser = function (description) { return cordova(this, "createUser", {}, arguments); };
    geosparkOriginal.prototype.setDescription = function (description) { return cordova(this, "setDescription", {}, arguments); };
    geosparkOriginal.prototype.getUser = function (description) { return cordova(this, "getUser", {}, arguments); };
    geosparkOriginal.prototype.toggleEvents = function (geofenceEvents, tripEvents, activityEvents) { return cordova(this, "toggleEvents", {}, arguments); };
    geosparkOriginal.prototype.getEventsStatus = function () { return cordova(this, "getEventsStatus", {}, arguments); };
    geosparkOriginal.prototype.startTrip = function (description, tripId) { return cordova(this, "startTrip", {}, arguments); };
    geosparkOriginal.prototype.resumeTrip = function (tripId) { return cordova(this, "resumeTrip", {}, arguments); };
    geosparkOriginal.prototype.pauseTrip = function (tripId) { return cordova(this, "pauseTrip", {}, arguments); };
    geosparkOriginal.prototype.endTrip = function (tripId) { return cordova(this, "endTrip", {}, arguments); };
    geosparkOriginal.prototype.activeTrips = function () { return cordova(this, "activeTrips", {}, arguments); };
    geosparkOriginal.prototype.getCurrentLocation = function (accuracy) { return cordova(this, "getCurrentLocation", {}, arguments); };
    geosparkOriginal.prototype.updateCurrentLocation = function (accuracy) { return cordova(this, "updateCurrentLocation", {}, arguments); };
    geosparkOriginal.prototype.startTracking = function () { return cordova(this, "startTracking", {}, arguments); };
    geosparkOriginal.prototype.stopTracking = function () { return cordova(this, "stopTracking", {}, arguments); };
    geosparkOriginal.prototype.isLocationTracking = function () { return cordova(this, "isLocationTracking", {}, arguments); };
    geosparkOriginal.prototype.logout = function () { return cordova(this, "logout", {}, arguments); };
    geosparkOriginal.prototype.setTrackingInAppState = function (typeArray) { return cordova(this, "setTrackingInAppState", {}, arguments); };
    geosparkOriginal.prototype.setTrackingInMotion = function (typeArray) { return cordova(this, "setTrackingInMotion", {}, arguments); };
    geosparkOriginal.prototype.onEvents = function () { return cordova(this, "onEvents", { "observable": true }, arguments); };
    geosparkOriginal.prototype.onError = function () { return cordova(this, "onError", { "observable": true }, arguments); };
    geosparkOriginal.prototype.offEvents = function () { return cordova(this, "offEvents", { "observable": true }, arguments); };
    geosparkOriginal.prototype.offError = function () { return cordova(this, "offError", { "observable": true }, arguments); };
    geosparkOriginal.pluginName = "Geospark";
    geosparkOriginal.plugin = "cordova-plugin-geospark";
    geosparkOriginal.pluginRef = "cordova.plugins.geospark";
    geosparkOriginal.repo = "https://github.com/geosparks/cordova-plugin-geospark";
    geosparkOriginal.platforms = ["Android", "iOS"];
    return geosparkOriginal;
}(IonicNativePlugin));
var geospark = new geosparkOriginal();
export { geospark };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvQGlvbmljLW5hdGl2ZS9wbHVnaW5zL2dlb3NwYXJrL2luZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7QUFDQSxPQUFPLDhCQUEwRixNQUFNLG9CQUFvQixDQUFDO0FBQzVILE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxNQUFNLENBQUM7O0lBU0osNEJBQWlCOzs7O0lBRTdDLDZDQUEwQjtJQUkxQiwrQ0FBNEI7SUFJNUIsMENBQXVCO0lBSXZCLDRDQUF5QjtJQUl6QiwwQ0FBdUI7SUFJdkIsNENBQXlCO0lBSXpCLHdDQUFxQjtJQUlyQiwwQ0FBdUI7SUFJdkIsb0RBQWlDO0lBSWpDLHNEQUFtQztJQUluQyxpQ0FBYztJQUlkLDZCQUFVLGFBQUMsV0FBbUI7SUFJOUIsaUNBQWMsYUFBQyxXQUFtQjtJQUlsQywwQkFBTyxhQUFDLFdBQW1CO0lBSTNCLCtCQUFZLGFBQUMsY0FBdUIsRUFBRSxVQUFtQixFQUFHLGNBQXVCO0lBSW5GLGtDQUFlO0lBSWYsNEJBQVMsYUFBQyxXQUFtQixFQUFFLE1BQWM7SUFJN0MsNkJBQVUsYUFBQyxNQUFjO0lBSXpCLDRCQUFTLGFBQUMsTUFBYztJQUl4QiwwQkFBTyxhQUFDLE1BQWM7SUFJdEIsOEJBQVc7SUFJWCxxQ0FBa0IsYUFBQyxRQUFnQjtJQUluQyx3Q0FBcUIsYUFBQyxRQUFnQjtJQUl0QyxnQ0FBYTtJQUliLCtCQUFZO0lBSVoscUNBQWtCO0lBSWxCLHlCQUFNO0lBSU4sd0NBQXFCLGFBQUMsU0FBaUI7SUFJdkMsc0NBQW1CLGFBQUMsU0FBaUI7SUFNckMsMkJBQVE7SUFNUiwwQkFBTztJQU1QLDRCQUFTO0lBTVQsMkJBQVE7Ozs7OzttQkFySlY7RUFXOEIsaUJBQWlCO1NBQWxDLFFBQVEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBQbHVnaW4sIENvcmRvdmEsIENvcmRvdmFQcm9wZXJ0eSwgQ29yZG92YUluc3RhbmNlLCBJbnN0YW5jZVByb3BlcnR5LCBJb25pY05hdGl2ZVBsdWdpbiB9IGZyb20gJ0Bpb25pYy1uYXRpdmUvY29yZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5AUGx1Z2luKHtcbiAgcGx1Z2luTmFtZTogJ0dlb3NwYXJrJyxcbiAgcGx1Z2luOiBcImNvcmRvdmEtcGx1Z2luLWdlb3NwYXJrXCIsXG4gIHBsdWdpblJlZjogXCJjb3Jkb3ZhLnBsdWdpbnMuZ2Vvc3BhcmtcIixcbiAgcmVwbzogXCJodHRwczovL2dpdGh1Yi5jb20vZ2Vvc3BhcmtzL2NvcmRvdmEtcGx1Z2luLWdlb3NwYXJrXCIsXG4gIHBsYXRmb3JtczogW1wiQW5kcm9pZFwiLCBcImlPU1wiXVxufSlcbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBnZW9zcGFyayBleHRlbmRzIElvbmljTmF0aXZlUGx1Z2luIHtcbiAgQENvcmRvdmEoKVxuICBkaXNhYmxlQmF0dGVyeU9wdGltaXphdGlvbigpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIGlzQmF0dGVyeU9wdGltaXphdGlvbkVuYWJsZWQoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBjaGVja0FjdGl2aXR5UGVybWlzc2lvbigpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIHJlcXVlc3RBY3Rpdml0eVBlcm1pc3Npb24oKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBjaGVja0xvY2F0aW9uUGVybWlzc2lvbigpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIHJlcXVlc3RMb2NhdGlvblBlcm1pc3Npb24oKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBjaGVja0xvY2F0aW9uU2VydmljZXMoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICByZXF1ZXN0TG9jYXRpb25TZXJ2aWNlcygpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIGNoZWNrQmFja2dyb3VuZExvY2F0aW9uUGVybWlzc2lvbigpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIHJlcXVlc3RCYWNrZ3JvdW5kTG9jYXRpb25QZXJtaXNzaW9uKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgZ2V0RGV2aWNlVG9rZW4oKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBjcmVhdGVVc2VyKGRlc2NyaXB0aW9uOiBTdHJpbmcpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIHNldERlc2NyaXB0aW9uKGRlc2NyaXB0aW9uOiBTdHJpbmcpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIGdldFVzZXIoZGVzY3JpcHRpb246IFN0cmluZyk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgdG9nZ2xlRXZlbnRzKGdlb2ZlbmNlRXZlbnRzOiBCb29sZWFuICx0cmlwRXZlbnRzOiBCb29sZWFuICwgYWN0aXZpdHlFdmVudHM6IEJvb2xlYW4pOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIGdldEV2ZW50c1N0YXR1cygpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIHN0YXJ0VHJpcChkZXNjcmlwdGlvbjogU3RyaW5nLCB0cmlwSWQ6IFN0cmluZyk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgcmVzdW1lVHJpcCh0cmlwSWQ6IFN0cmluZyk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgcGF1c2VUcmlwKHRyaXBJZDogU3RyaW5nKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBlbmRUcmlwKHRyaXBJZDogU3RyaW5nKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBhY3RpdmVUcmlwcygpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIGdldEN1cnJlbnRMb2NhdGlvbihhY2N1cmFjeTogTnVtYmVyKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICB1cGRhdGVDdXJyZW50TG9jYXRpb24oYWNjdXJhY3k6IE51bWJlcik6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgc3RhcnRUcmFja2luZygpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIHN0b3BUcmFja2luZygpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIGlzTG9jYXRpb25UcmFja2luZygpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIGxvZ291dCgpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIHNldFRyYWNraW5nSW5BcHBTdGF0ZSh0eXBlQXJyYXk6IFN0cmluZyk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgc2V0VHJhY2tpbmdJbk1vdGlvbih0eXBlQXJyYXk6IFN0cmluZyk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKHtcbiAgICBvYnNlcnZhYmxlOiB0cnVlXG4gIH0pXG4gIG9uRXZlbnRzKCk6IE9ic2VydmFibGU8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKHtcbiAgICBvYnNlcnZhYmxlOiB0cnVlXG4gIH0pXG4gIG9uRXJyb3IoKTogT2JzZXJ2YWJsZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoe1xuICAgIG9ic2VydmFibGU6IHRydWVcbiAgfSlcbiAgb2ZmRXZlbnRzKCk6IE9ic2VydmFibGU8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKHtcbiAgICBvYnNlcnZhYmxlOiB0cnVlXG4gIH0pXG4gIG9mZkVycm9yKCk6IE9ic2VydmFibGU8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG59Il19