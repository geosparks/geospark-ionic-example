var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
import { IonicNativePlugin, cordova } from '@ionic-native/core';
var geosparkOriginal = /** @class */ (function (_super) {
    __extends(geosparkOriginal, _super);
    function geosparkOriginal() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    geosparkOriginal.prototype.disableBatteryOptimization = function () { return cordova(this, "disableBatteryOptimization", {}, arguments); };
    geosparkOriginal.prototype.isBatteryOptimizationEnabled = function () { return cordova(this, "isBatteryOptimizationEnabled", {}, arguments); };
    geosparkOriginal.prototype.checkActivityPermission = function () { return cordova(this, "checkActivityPermission", {}, arguments); };
    geosparkOriginal.prototype.requestActivityPermission = function () { return cordova(this, "requestActivityPermission", {}, arguments); };
    geosparkOriginal.prototype.checkLocationPermission = function () { return cordova(this, "checkLocationPermission", {}, arguments); };
    geosparkOriginal.prototype.requestLocationPermission = function () { return cordova(this, "requestLocationPermission", {}, arguments); };
    geosparkOriginal.prototype.checkLocationServices = function () { return cordova(this, "checkLocationServices", {}, arguments); };
    geosparkOriginal.prototype.requestLocationServices = function () { return cordova(this, "requestLocationServices", {}, arguments); };
    geosparkOriginal.prototype.checkBackgroundLocationPermission = function () { return cordova(this, "checkBackgroundLocationPermission", {}, arguments); };
    geosparkOriginal.prototype.requestBackgroundLocationPermission = function () { return cordova(this, "requestBackgroundLocationPermission", {}, arguments); };
    geosparkOriginal.prototype.getDeviceToken = function () { return cordova(this, "getDeviceToken", {}, arguments); };
    geosparkOriginal.prototype.createUser = function (description) { return cordova(this, "createUser", {}, arguments); };
    geosparkOriginal.prototype.setDescription = function (description) { return cordova(this, "setDescription", {}, arguments); };
    geosparkOriginal.prototype.getUser = function (description) { return cordova(this, "getUser", {}, arguments); };
    geosparkOriginal.prototype.toggleEvents = function (geofenceEvents, tripEvents, activityEvents) { return cordova(this, "toggleEvents", {}, arguments); };
    geosparkOriginal.prototype.getEventsStatus = function () { return cordova(this, "getEventsStatus", {}, arguments); };
    geosparkOriginal.prototype.startTrip = function (description, tripId) { return cordova(this, "startTrip", {}, arguments); };
    geosparkOriginal.prototype.resumeTrip = function (tripId) { return cordova(this, "resumeTrip", {}, arguments); };
    geosparkOriginal.prototype.pauseTrip = function (tripId) { return cordova(this, "pauseTrip", {}, arguments); };
    geosparkOriginal.prototype.endTrip = function (tripId) { return cordova(this, "endTrip", {}, arguments); };
    geosparkOriginal.prototype.activeTrips = function () { return cordova(this, "activeTrips", {}, arguments); };
    geosparkOriginal.prototype.getCurrentLocation = function (accuracy) { return cordova(this, "getCurrentLocation", {}, arguments); };
    geosparkOriginal.prototype.updateCurrentLocation = function (accuracy) { return cordova(this, "updateCurrentLocation", {}, arguments); };
    geosparkOriginal.prototype.startTracking = function () { return cordova(this, "startTracking", {}, arguments); };
    geosparkOriginal.prototype.stopTracking = function () { return cordova(this, "stopTracking", {}, arguments); };
    geosparkOriginal.prototype.isLocationTracking = function () { return cordova(this, "isLocationTracking", {}, arguments); };
    geosparkOriginal.prototype.logout = function () { return cordova(this, "logout", {}, arguments); };
    geosparkOriginal.prototype.setTrackingInAppState = function (typeArray) { return cordova(this, "setTrackingInAppState", {}, arguments); };
    geosparkOriginal.prototype.setTrackingInMotion = function (typeArray) { return cordova(this, "setTrackingInMotion", {}, arguments); };
    geosparkOriginal.prototype.onEvents = function () { return cordova(this, "onEvents", {}, arguments); };
    geosparkOriginal.prototype.onError = function () { return cordova(this, "onError", {}, arguments); };
    geosparkOriginal.prototype.offEvents = function () { return cordova(this, "offEvents", {}, arguments); };
    geosparkOriginal.prototype.offError = function () { return cordova(this, "offError", {}, arguments); };
    geosparkOriginal.pluginName = "Geospark";
    geosparkOriginal.plugin = "cordova-plugin-geospark";
    geosparkOriginal.pluginRef = "cordova.plugins.geospark";
    geosparkOriginal.repo = "https://github.com/geosparks/cordova-plugin-geospark";
    geosparkOriginal.platforms = ["Android", "iOS"];
    return geosparkOriginal;
}(IonicNativePlugin));
var geospark = new geosparkOriginal();
export { geospark };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvQGlvbmljLW5hdGl2ZS9wbHVnaW5zL2dlb3NwYXJrL2luZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7QUFDQSxPQUFPLDhCQUEwRixNQUFNLG9CQUFvQixDQUFDOztJQVc5Riw0QkFBaUI7Ozs7SUFHN0MsNkNBQTBCO0lBSTFCLCtDQUE0QjtJQUk1QiwwQ0FBdUI7SUFJdkIsNENBQXlCO0lBSXpCLDBDQUF1QjtJQUl2Qiw0Q0FBeUI7SUFJekIsd0NBQXFCO0lBSXJCLDBDQUF1QjtJQUl2QixvREFBaUM7SUFJakMsc0RBQW1DO0lBSW5DLGlDQUFjO0lBSWQsNkJBQVUsYUFBQyxXQUFtQjtJQUk5QixpQ0FBYyxhQUFDLFdBQW1CO0lBSWxDLDBCQUFPLGFBQUMsV0FBbUI7SUFJM0IsK0JBQVksYUFBQyxjQUF1QixFQUFFLFVBQW1CLEVBQUcsY0FBdUI7SUFJbkYsa0NBQWU7SUFJZiw0QkFBUyxhQUFDLFdBQW1CLEVBQUUsTUFBYztJQUk3Qyw2QkFBVSxhQUFDLE1BQWM7SUFJekIsNEJBQVMsYUFBQyxNQUFjO0lBSXhCLDBCQUFPLGFBQUMsTUFBYztJQUl0Qiw4QkFBVztJQUlYLHFDQUFrQixhQUFDLFFBQWdCO0lBSW5DLHdDQUFxQixhQUFDLFFBQWdCO0lBSXRDLGdDQUFhO0lBSWIsK0JBQVk7SUFJWixxQ0FBa0I7SUFJbEIseUJBQU07SUFJTix3Q0FBcUIsYUFBQyxTQUFpQjtJQUl2QyxzQ0FBbUIsYUFBQyxTQUFpQjtJQUlyQywyQkFBUTtJQUlSLDBCQUFPO0lBSVAsNEJBQVM7SUFJVCwyQkFBUTs7Ozs7O21CQS9JVjtFQVk4QixpQkFBaUI7U0FBbEMsUUFBUSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFBsdWdpbiwgQ29yZG92YSwgQ29yZG92YVByb3BlcnR5LCBDb3Jkb3ZhSW5zdGFuY2UsIEluc3RhbmNlUHJvcGVydHksIElvbmljTmF0aXZlUGx1Z2luIH0gZnJvbSAnQGlvbmljLW5hdGl2ZS9jb3JlJztcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcblxuQFBsdWdpbih7XG4gIHBsdWdpbk5hbWU6ICdHZW9zcGFyaycsXG4gIHBsdWdpbjogXCJjb3Jkb3ZhLXBsdWdpbi1nZW9zcGFya1wiLFxuICBwbHVnaW5SZWY6IFwiY29yZG92YS5wbHVnaW5zLmdlb3NwYXJrXCIsXG4gIHJlcG86IFwiaHR0cHM6Ly9naXRodWIuY29tL2dlb3NwYXJrcy9jb3Jkb3ZhLXBsdWdpbi1nZW9zcGFya1wiLFxuICBwbGF0Zm9ybXM6IFtcIkFuZHJvaWRcIiwgXCJpT1NcIl1cbn0pXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgZ2Vvc3BhcmsgZXh0ZW5kcyBJb25pY05hdGl2ZVBsdWdpbiB7XG4gXG4gIEBDb3Jkb3ZhKClcbiAgZGlzYWJsZUJhdHRlcnlPcHRpbWl6YXRpb24oKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBpc0JhdHRlcnlPcHRpbWl6YXRpb25FbmFibGVkKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgY2hlY2tBY3Rpdml0eVBlcm1pc3Npb24oKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICByZXF1ZXN0QWN0aXZpdHlQZXJtaXNzaW9uKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgY2hlY2tMb2NhdGlvblBlcm1pc3Npb24oKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICByZXF1ZXN0TG9jYXRpb25QZXJtaXNzaW9uKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgY2hlY2tMb2NhdGlvblNlcnZpY2VzKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgcmVxdWVzdExvY2F0aW9uU2VydmljZXMoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBjaGVja0JhY2tncm91bmRMb2NhdGlvblBlcm1pc3Npb24oKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICByZXF1ZXN0QmFja2dyb3VuZExvY2F0aW9uUGVybWlzc2lvbigpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIGdldERldmljZVRva2VuKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgY3JlYXRlVXNlcihkZXNjcmlwdGlvbjogU3RyaW5nKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBzZXREZXNjcmlwdGlvbihkZXNjcmlwdGlvbjogU3RyaW5nKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBnZXRVc2VyKGRlc2NyaXB0aW9uOiBTdHJpbmcpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIHRvZ2dsZUV2ZW50cyhnZW9mZW5jZUV2ZW50czogQm9vbGVhbiAsdHJpcEV2ZW50czogQm9vbGVhbiAsIGFjdGl2aXR5RXZlbnRzOiBCb29sZWFuKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBnZXRFdmVudHNTdGF0dXMoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBzdGFydFRyaXAoZGVzY3JpcHRpb246IFN0cmluZywgdHJpcElkOiBTdHJpbmcpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIHJlc3VtZVRyaXAodHJpcElkOiBTdHJpbmcpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIHBhdXNlVHJpcCh0cmlwSWQ6IFN0cmluZyk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgZW5kVHJpcCh0cmlwSWQ6IFN0cmluZyk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgYWN0aXZlVHJpcHMoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBnZXRDdXJyZW50TG9jYXRpb24oYWNjdXJhY3k6IE51bWJlcik6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgdXBkYXRlQ3VycmVudExvY2F0aW9uKGFjY3VyYWN5OiBOdW1iZXIpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIHN0YXJ0VHJhY2tpbmcoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBzdG9wVHJhY2tpbmcoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBpc0xvY2F0aW9uVHJhY2tpbmcoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBsb2dvdXQoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgQENvcmRvdmEoKVxuICBzZXRUcmFja2luZ0luQXBwU3RhdGUodHlwZUFycmF5OiBTdHJpbmcpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIHNldFRyYWNraW5nSW5Nb3Rpb24odHlwZUFycmF5OiBTdHJpbmcpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIG9uRXZlbnRzKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIEBDb3Jkb3ZhKClcbiAgb25FcnJvcigpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIG9mZkV2ZW50cygpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuICBAQ29yZG92YSgpXG4gIG9mZkVycm9yKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG59XG4iXX0=