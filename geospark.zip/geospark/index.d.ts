import { IonicNativePlugin } from '@ionic-native/core';
export declare class geosparkOriginal extends IonicNativePlugin {
    disableBatteryOptimization(): Promise<any>;
    isBatteryOptimizationEnabled(): Promise<any>;
    checkActivityPermission(): Promise<any>;
    requestActivityPermission(): Promise<any>;
    checkLocationPermission(): Promise<any>;
    requestLocationPermission(): Promise<any>;
    checkLocationServices(): Promise<any>;
    requestLocationServices(): Promise<any>;
    checkBackgroundLocationPermission(): Promise<any>;
    requestBackgroundLocationPermission(): Promise<any>;
    getDeviceToken(): Promise<any>;
    createUser(description: String): Promise<any>;
    setDescription(description: String): Promise<any>;
    getUser(description: String): Promise<any>;
    toggleEvents(geofenceEvents: Boolean, tripEvents: Boolean, activityEvents: Boolean): Promise<any>;
    getEventsStatus(): Promise<any>;
    startTrip(description: String, tripId: String): Promise<any>;
    resumeTrip(tripId: String): Promise<any>;
    pauseTrip(tripId: String): Promise<any>;
    endTrip(tripId: String): Promise<any>;
    activeTrips(): Promise<any>;
    getCurrentLocation(accuracy: Number): Promise<any>;
    updateCurrentLocation(accuracy: Number): Promise<any>;
    startTracking(): Promise<any>;
    stopTracking(): Promise<any>;
    isLocationTracking(): Promise<any>;
    logout(): Promise<any>;
    setTrackingInAppState(typeArray: String): Promise<any>;
    setTrackingInMotion(typeArray: String): Promise<any>;
    onEvents(): Promise<any>;
    onError(): Promise<any>;
    offEvents(): Promise<any>;
    offError(): Promise<any>;
}

export declare const geospark: geosparkOriginal;